-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 15, 2022 at 08:34 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pengenalan_hurup_hijaiyah`
--

-- --------------------------------------------------------

--
-- Table structure for table `dhammah`
--

CREATE TABLE `dhammah` (
  `id` int(11) NOT NULL,
  `hurup_1` varchar(10) NOT NULL,
  `hurup_2` varchar(25) NOT NULL,
  `sound` varchar(75) NOT NULL,
  `cbg` varchar(15) NOT NULL,
  `ctxt` varchar(15) NOT NULL,
  `tgl_input` datetime NOT NULL,
  `deskripsi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dhammah`
--

INSERT INTO `dhammah` (`id`, `hurup_1`, `hurup_2`, `sound`, `cbg`, `ctxt`, `tgl_input`, `deskripsi`) VALUES
(2, 'dhammah', 'dhammah', '', '#3d45b3', '#ffffff', '2022-09-15 00:22:13', 'asd ada fsef sffffffff bgnnnnnnnnnnnnn ryuuuuu');

-- --------------------------------------------------------

--
-- Table structure for table `fathah`
--

CREATE TABLE `fathah` (
  `id` int(11) NOT NULL,
  `hurup_1` varchar(10) NOT NULL,
  `hurup_2` varchar(25) NOT NULL,
  `sound` varchar(75) NOT NULL,
  `cbg` varchar(15) NOT NULL,
  `ctxt` varchar(15) NOT NULL,
  `tgl_input` datetime NOT NULL,
  `deskripsi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fathah`
--

INSERT INTO `fathah` (`id`, `hurup_1`, `hurup_2`, `sound`, `cbg`, `ctxt`, `tgl_input`, `deskripsi`) VALUES
(3, 'Fathah', 'Fathah', '', '#216c8c', '#ffffff', '2022-09-14 23:51:49', 'asdas ae afawd');

-- --------------------------------------------------------

--
-- Table structure for table `hurup_hijaiyah`
--

CREATE TABLE `hurup_hijaiyah` (
  `id` int(11) NOT NULL,
  `hurup_1` varchar(10) NOT NULL,
  `hurup_2` varchar(35) NOT NULL,
  `sound` varchar(80) DEFAULT NULL,
  `cbg` varchar(15) NOT NULL,
  `ctxt` varchar(15) NOT NULL,
  `tgl_input` datetime NOT NULL,
  `deskripsi` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hurup_hijaiyah`
--

INSERT INTO `hurup_hijaiyah` (`id`, `hurup_1`, `hurup_2`, `sound`, `cbg`, `ctxt`, `tgl_input`, `deskripsi`) VALUES
(676598831, 'ب  ', '(Ba)', '9885c7ac900ffdae54392675213b0695.mp3', '#3c9ffb', '#000000', '2022-07-27 04:10:15', 'Lorem ipsum dolor sit amet, consectetur adipisicin,Lorem ipsum dolor sit amet, consectetur adipisicinLorem ipsum dolor sit amet, consectetur adipisicinLorem ipsum dolor sit amet, consectetur adipisicinLorem ipsum dolor sit amet, consectetur adipisicin'),
(1554653242, 'ا ', '(Alif)', '7a4b43c0ff126efb710036d14b50fef8.mp3', '#aa319a', '#ffffff', '2022-07-27 04:08:00', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.');

-- --------------------------------------------------------

--
-- Table structure for table `kasrah`
--

CREATE TABLE `kasrah` (
  `id` int(11) NOT NULL,
  `hurup_1` varchar(10) NOT NULL,
  `hurup_2` varchar(25) NOT NULL,
  `sound` varchar(75) NOT NULL,
  `cbg` varchar(15) NOT NULL,
  `ctxt` varchar(15) NOT NULL,
  `tgl_input` datetime NOT NULL,
  `deskripsi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kasrah`
--

INSERT INTO `kasrah` (`id`, `hurup_1`, `hurup_2`, `sound`, `cbg`, `ctxt`, `tgl_input`, `deskripsi`) VALUES
(2, 'kasrah', 'kasrah', '', '#4bf81b', '#545454', '2022-09-15 00:07:45', 'casc as rg erg erh rtjee fd fd');

-- --------------------------------------------------------

--
-- Table structure for table `pengguna`
--

CREATE TABLE `pengguna` (
  `p_id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pengguna`
--

INSERT INTO `pengguna` (`p_id`, `nama`, `username`, `password`) VALUES
(1, 'Annnz', 'input', '$2y$10$x2roVb2x1yL687J9gNulQ.tVJGkt26P80jG6eZ0NUvc1FgpMWe75K'),
(3, 'assssssss', '1234', '$2y$10$2ucmdmduah1EcB/eFokMwOpvx92fWMlv5xG7CtsyBfqw9F.fdj.xa');

-- --------------------------------------------------------

--
-- Table structure for table `tajwid`
--

CREATE TABLE `tajwid` (
  `id` int(11) NOT NULL,
  `hurup_1` varchar(10) NOT NULL,
  `hurup_2` varchar(25) NOT NULL,
  `sound` varchar(75) NOT NULL,
  `cbg` varchar(15) NOT NULL,
  `ctxt` varchar(15) NOT NULL,
  `tgl_input` datetime NOT NULL,
  `deskripsi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tajwid`
--

INSERT INTO `tajwid` (`id`, `hurup_1`, `hurup_2`, `sound`, `cbg`, `ctxt`, `tgl_input`, `deskripsi`) VALUES
(1, 'tajwid', 'tajwid', '', '#ff4405', '#ffffff', '2022-09-16 00:50:47', 'lorems lorems lorems lorems lorems\r\nlorems lorems lorems lorems lorems');

-- --------------------------------------------------------

--
-- Table structure for table `tanwin_dhammah`
--

CREATE TABLE `tanwin_dhammah` (
  `id` int(11) NOT NULL,
  `hurup_1` varchar(10) NOT NULL,
  `hurup_2` varchar(25) NOT NULL,
  `sound` varchar(75) NOT NULL,
  `cbg` varchar(15) NOT NULL,
  `ctxt` varchar(15) NOT NULL,
  `tgl_input` datetime NOT NULL,
  `deskripsi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tanwin_dhammah`
--

INSERT INTO `tanwin_dhammah` (`id`, `hurup_1`, `hurup_2`, `sound`, `cbg`, `ctxt`, `tgl_input`, `deskripsi`) VALUES
(1, 'tanwin dha', 'tanwin dhammah', '', '#ad009f', '#ffffff', '2022-09-16 00:46:14', 'uhasduauys dwtauwd asydga ydgasudhjas djagsdjfw fwef');

-- --------------------------------------------------------

--
-- Table structure for table `tanwin_fathah`
--

CREATE TABLE `tanwin_fathah` (
  `id` int(11) NOT NULL,
  `hurup_1` varchar(10) NOT NULL,
  `hurup_2` varchar(25) NOT NULL,
  `sound` varchar(75) NOT NULL,
  `cbg` varchar(15) NOT NULL,
  `ctxt` varchar(15) NOT NULL,
  `tgl_input` datetime NOT NULL,
  `deskripsi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tanwin_fathah`
--

INSERT INTO `tanwin_fathah` (`id`, `hurup_1`, `hurup_2`, `sound`, `cbg`, `ctxt`, `tgl_input`, `deskripsi`) VALUES
(2, 'tanwin fat', 'tanwin fathah', '', '#c819c2', '#ffffff', '2022-09-15 00:35:16', 'dasd nuahsdh aus diasbdasd aos domaojwd adasffwf af ds ');

-- --------------------------------------------------------

--
-- Table structure for table `tanwin_kasrah`
--

CREATE TABLE `tanwin_kasrah` (
  `id` int(11) NOT NULL,
  `hurup_1` varchar(10) NOT NULL,
  `hurup_2` varchar(25) NOT NULL,
  `sound` varchar(75) NOT NULL,
  `cbg` varchar(15) NOT NULL,
  `ctxt` varchar(15) NOT NULL,
  `tgl_input` datetime NOT NULL,
  `deskripsi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tanwin_kasrah`
--

INSERT INTO `tanwin_kasrah` (`id`, `hurup_1`, `hurup_2`, `sound`, `cbg`, `ctxt`, `tgl_input`, `deskripsi`) VALUES
(2, 'tanwin kas', 'tanwin kasrah', '', '#12ba52', '#fcfcfc', '2022-09-16 00:45:22', 'asd asdbuyf ftkkkkkkkkkty reuuuuuerrrrrrrrrrrrr tttttt');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dhammah`
--
ALTER TABLE `dhammah`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fathah`
--
ALTER TABLE `fathah`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hurup_hijaiyah`
--
ALTER TABLE `hurup_hijaiyah`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kasrah`
--
ALTER TABLE `kasrah`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `tajwid`
--
ALTER TABLE `tajwid`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tanwin_dhammah`
--
ALTER TABLE `tanwin_dhammah`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tanwin_fathah`
--
ALTER TABLE `tanwin_fathah`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tanwin_kasrah`
--
ALTER TABLE `tanwin_kasrah`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dhammah`
--
ALTER TABLE `dhammah`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `fathah`
--
ALTER TABLE `fathah`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `hurup_hijaiyah`
--
ALTER TABLE `hurup_hijaiyah`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1554653244;

--
-- AUTO_INCREMENT for table `kasrah`
--
ALTER TABLE `kasrah`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tajwid`
--
ALTER TABLE `tajwid`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tanwin_dhammah`
--
ALTER TABLE `tanwin_dhammah`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tanwin_fathah`
--
ALTER TABLE `tanwin_fathah`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tanwin_kasrah`
--
ALTER TABLE `tanwin_kasrah`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
