-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 27 Jul 2022 pada 05.08
-- Versi server: 10.4.24-MariaDB
-- Versi PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pengenalan_hurup_hijaiyah`
--
CREATE DATABASE IF NOT EXISTS `pengenalan_hurup_hijaiyah` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `pengenalan_hurup_hijaiyah`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `hurup_hijaiyah`
--

CREATE TABLE `hurup_hijaiyah` (
  `hh_id` varchar(45) NOT NULL,
  `hurup_1` varchar(10) NOT NULL,
  `hurup_2` varchar(35) NOT NULL,
  `h_sound` varchar(80) DEFAULT NULL,
  `h_cbg` varchar(15) NOT NULL,
  `h_ctxt` varchar(15) NOT NULL,
  `tgl_input` datetime NOT NULL,
  `deskripsi` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `hurup_hijaiyah`
--

INSERT INTO `hurup_hijaiyah` (`hh_id`, `hurup_1`, `hurup_2`, `h_sound`, `h_cbg`, `h_ctxt`, `tgl_input`, `deskripsi`) VALUES
('1554653242', 'ا ', '(Alif)', '7a4b43c0ff126efb710036d14b50fef8.mp3', '#aa319a', '#ffffff', '2022-07-27 04:08:00', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
('676598831', 'ب  ', '(Ba)', '9885c7ac900ffdae54392675213b0695.mp3', '#3c9ffb', '#000000', '2022-07-27 04:10:15', 'Lorem ipsum dolor sit amet, consectetur adipisicin,Lorem ipsum dolor sit amet, consectetur adipisicinLorem ipsum dolor sit amet, consectetur adipisicinLorem ipsum dolor sit amet, consectetur adipisicinLorem ipsum dolor sit amet, consectetur adipisicin');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengguna`
--

CREATE TABLE `pengguna` (
  `p_id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pengguna`
--

INSERT INTO `pengguna` (`p_id`, `nama`, `username`, `password`) VALUES
(1, 'Annnz', 'input', '$2y$10$x2roVb2x1yL687J9gNulQ.tVJGkt26P80jG6eZ0NUvc1FgpMWe75K'),
(2, 'aaaaaaaaaaaa', '123', '$2y$10$Y7DTh2x0j103JSqJ.rIDkeSbQaF.EIry3oonnvvfTFEHopRR/II/y'),
(3, 'assssssss', '1234', '$2y$10$2ucmdmduah1EcB/eFokMwOpvx92fWMlv5xG7CtsyBfqw9F.fdj.xa');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `hurup_hijaiyah`
--
ALTER TABLE `hurup_hijaiyah`
  ADD PRIMARY KEY (`hh_id`);

--
-- Indeks untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`p_id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
