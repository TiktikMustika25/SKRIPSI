<?php 
	$pSess = $this->session->userdata('data_penggunaSess');
 ?>

<div id="contain-login"
<?php if (isset($pSess['p_id']) && isset($pSess['nama']) && isset($pSess['username']) || $pSess){
	echo 'class="contain-login-hide"';
} else {
	echo 'class="contain-login-show"';
} ?>
>
	<div class="card w-50 p-4 shadow" data-aos="zoom-in">
		<div class="card-body">
			<!-- <div class="alert alert-success"> <strong>berhasil login</strong> </div> -->
			<h4 class="text-center p-3"> <b>Login Menu</b> </h4>
			<div><?= $this->session->flashdata('pesan_data'); ?></div>
			<form action="<?= base_url('pengguna/login_process/'.$this->uri->segment(1));?>" method="post">
				<div class="my-2">
					<label class="w-100">
						<b>Username: </b>
						<input type="text" class="form-control" name="username" placeholder="ketikan username.." required>
					</label>
				</div>
				<div class="my-2">
					<label class="w-100">
						<b>Password: </b>
						<input type="password" class="form-control" name="password" placeholder="ketikan username.." required>
					</label>
				</div>
				<div class="my-2">
					<button type="submit" class="btn btn-primary"> Login </button>
					<a href="<?= base_url('home');?>" class="btn btn-info"> <i class="fas fa-home"></i> </a>
				</div>
			</form>
		</div>
	</div>
</div>