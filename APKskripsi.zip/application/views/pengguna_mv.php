<!-- Modal Pengguna -->
<div class="modal fade" id="m-data-pengguna">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-body">
				<button type="button" class="btn btn-sm close float-end" data-bs-dismiss="modal"> <i class="fa fa-times"></i> </button>
				<h4 class="text-center p-2"> Data pengguna </h4>
				<div class="row w-100 my-3">
					<div class="col-xl-4">
						<div class="card bg-success text-white my-2">
							<div class="card-header">
								<a class="text-white" data-bs-toggle="collapse" href="#form-tambah-pengguna" title=""><h5 class="text-center p-2">Tambah pengguna</h5></a>	
							</div>
							<div class="card-body collapse" id="form-tambah-pengguna">
								<form action="<?= base_url('pengguna/tambah_pengguna/'.$this->uri->segment(1));?>" method="post">
									<div class="my-2">
										<label class="w-100">
											Nama:
											<input type="text" class="form-control" name="nama-usr-ins" placeholder="ketikan nama.." required>
										</label>
									</div>
									<div class="my-2">
										<label class="w-100">
											Username:
											<input type="text" class="form-control" name="username-usr-ins" placeholder="ketikan nama.." required>
										</label>
									</div>
									<div class="my-2">
										<label class="w-100">
											Password:
											<input type="password" class="form-control" name="password-usr-ins" placeholder="ketikan nama.." required>
										</label>
									</div>
									<div class="my-2">
										<button type="submit" class="btn btn-secondary w-100"> tambah </button>
									</div>
								</form>	
							</div>
						</div>				
					</div>
					<div class="col-xl-4">
						<div class="card bg-primary text-white my-2">
							<div class="card-header">
								<a class="text-white" data-bs-toggle="collapse" href="#form-edit-pengguna" title=""><h5 class="text-center p-2">Edit pengguna</h5></a>	
							</div>
							<div class="card-body collapse" id="form-edit-pengguna">
								<form action="<?= base_url('pengguna/edit_pengguna/'.$this->uri->segment(1));?>" method="post">
									<div class="my-2">
										<label class="w-100">
											Nama:
											<input type="text" class="form-control" name="nama-usr-edit" placeholder="ketikan nama.." required />
										</label>
									</div>
									<div class="my-2">
										<label class="w-100">
											Username:
											<input type="text" class="form-control" name="username-usr-edit" placeholder="ketikan nama.." required />
										</label>
									</div>
									<div class="my-2">
										<button type="button" class="btn btn-secondary w-100"> edit </button>
									</div>
								</form>	
							</div>
						</div>
					</div>
					<div class="col-xl-4">
						<div class="card bg-warning text-white my-2">
							<div class="card-header">
								<a class="text-white" data-bs-toggle="collapse" href="#form-cpwd-pengguna" title=""><h5 class="text-center p-2">Ubah password</h5></a>	
							</div>
							<div class="card-body collapse" id="form-cpwd-pengguna">
								<form action="<?= base_url('pengguna/cpwd_pengguna/'.$this->uri->segment(1));?>" method="post">
									<div class="my-2">
										<label class="w-100">
											Nama:
											<input type="text" class="form-control" name="cpwd-nama-usr" placeholder="nama, klik icon password!" required />
										</label>
									</div>
									<div class="my-2">
										<label class="w-100">
											Password:
											<input type="password" class="form-control" name="cpwd-usr" placeholder="ketikan password.." required />
										</label>
									</div>
									<div class="my-2">
										<button type="button" class="btn btn-secondary w-100"> ubah password </button>
									</div>
								</form>	
							</div>
						</div>
					</div>
				</div>
				<table id="table-pengguna" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th>#</th>
							<th>Nama</th>
							<th>Username</th>
							<th><i class="fa fa-cogs"></i></th>
						</tr>
					</thead>
					<tbody>
						<?php $i=1; foreach ($pengguna as $p){?>
							<tr>
								<td><?= $i++; ?></td>
								<td><?= $p['nama'];?></td>
								<td><?= $p['username'];?></td>
								<td>
									<a class="btn btn-primary btn-sm btn-edit-usr"
									pid="<?= $p['p_id'];?>"
									nama="<?= $p['nama'];?>"
									username="<?= $p['username'];?>"> <i class="fas fa-edit"></i> </a>
									<a class="btn btn-warning btn-sm btn-cpwd-usr"
									pid="<?= $p['p_id'];?>"
									nama="<?= $p['nama'];?>"> <i class="fas fa-key"></i> </a>
									<a onClick="return confirm('hapus data pengguna ( <?= $p['nama'];?> ) ?');" href="<?= base_url('pengguna/hapus_pengguna/'.$p['p_id'].'/'.$this->uri->segment(1));?>" class="btn btn-danger btn-sm"> <i class="fas fa-trash"></i> </a>
								</td>
							</tr>
						<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>