<?php $this->load->view('layout/header'); ?>
<?php $this->load->view('login_view'); ?>
<div class="container content-app">
	<?php $this->load->view('layout/navbar2'); ?>
	<button class="btn btn-outline-success w-100 mt-1 mb-2" data-aos="zoom-in" data-bs-toggle="modal" data-bs-target="#m-tambah-hurup"> <i class="fa fa-plus-circle"></i> Tambah Huruf </button>
	<div><?= $this->session->flashdata('pesan_data'); ?></div>
	<div class="row" id="area-hurup-hijaiyah">
		<div class="col-xl-3 my-3" data-aos="zoom-in">
			<div class="card shadow bg-warning">
				<div class="card-body text-center">
					<h1><?= $total_pengguna;?></h1>
					<small><i>Total Pengguna</i></small>
					<div class="mt-2 p-2" style="background-color:rgba(0,0,0,0.35);border-radius:5px;">
						<a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#m-data-pengguna" class="text-white"> <i class="fa fa-users"></i> Pengguna Input.</a>
					</div>
				</div>
			</div>
		</div>
		<div class="col-xl-3 my-3" data-aos="zoom-in">
			<div class="card shadow bg-info">
				<div class="card-body text-center">
					<h1><?= $total_fathah;?></h1>
					<small><i>Total Huruf Fathah</i></small>
					<div class="mt-2 p-2" style="background-color:rgba(0,0,0,0.35);border-radius:5px;">
						<a href="<?= base_url('fathah/input');?>" class="text-white"> <i class="fa fa-eye"></i> Lihat Lainnya.</a>
					</div>
				</div>
			</div>
		</div>
		<div class="col-xl-3 my-3" data-aos="zoom-in">
			<div class="card shadow bg-success">
				<div class="card-body text-center">
					<h1><?= $total_kasrah;?></h1>
					<small><i>Total Huruf Kasrah</i></small>
					<div class="mt-2 p-2" style="background-color:rgba(0,0,0,0.35);border-radius:5px;">
						<a href="<?= base_url('kasrah/input');?>" class="text-white"> <i class="fa fa-eye"></i> Lihat Lainnya.</a>
					</div>
				</div>
			</div>
		</div>
		<div class="col-xl-3 my-3" data-aos="zoom-in">
			<div class="card shadow bg-primary">
				<div class="card-body text-center">
					<h1><?= $total_dhammah;?></h1>
					<small><i>Total Huruf Dhammah</i></small>
					<div class="mt-2 p-2" style="background-color:rgba(0,0,0,0.35);border-radius:5px;">
						<a href="<?= base_url('dhammah/input');?>" class="text-white"> <i class="fa fa-eye"></i> Lihat Lainnya.</a>
					</div>
				</div>
			</div>
		</div>
		<div class="col-xl-3 my-3" data-aos="zoom-in">
			<div class="card shadow bg-info">
				<div class="card-body text-center">
					<h1><?= $total_tfathah;?></h1>
					<small><i>Total Huruf Tanwin Fathah</i></small>
					<div class="mt-2 p-2" style="background-color:rgba(0,0,0,0.35);border-radius:5px;">
						<a href="<?= base_url('tanwin_fathah/input');?>" class="text-white"> <i class="fa fa-eye"></i> Lihat Lainnya.</a>
					</div>
				</div>
			</div>
		</div>
		<div class="col-xl-3 my-3" data-aos="zoom-in">
			<div class="card shadow" style="background-color:lightgreen;">
				<div class="card-body text-center">
					<h1><?= $total_tkasrah;?></h1>
					<small><i>Total Huruf Tanwin Kasrah</i></small>
					<div class="mt-2 p-2" style="background-color:rgba(0,0,0,0.35);border-radius:5px;">
						<a href="<?= base_url('tanwin_kasrah/input');?>" class="text-white"> <i class="fa fa-eye"></i> Lihat Lainnya.</a>
					</div>
				</div>
			</div>
		</div>
		<div class="col-xl-3 my-3" data-aos="zoom-in">
			<div class="card shadow" style="background-color:#0197F4;">
				<div class="card-body text-center">
					<h1><?= $total_tdhammah;?></h1>
					<small><i>Total Huruf Tanwin Dhammah</i></small>
					<div class="mt-2 p-2" style="background-color:rgba(0,0,0,0.35);border-radius:5px;">
						<a href="<?= base_url('tanwin_dhammah/input');?>" class="text-white"> <i class="fa fa-eye"></i> Lihat Lainnya.</a>
					</div>
				</div>
			</div>
		</div>
		<div class="col-xl-3 my-3" data-aos="zoom-in">
			<div class="card shadow bg-danger">
				<div class="card-body text-center">
					<h1><?= $total_tajwid;?></h1>
					<small><i>Total Huruf Tajwid</i></small>
					<div class="mt-2 p-2" style="background-color:rgba(0,0,0,0.35);border-radius:5px;">
						<a href="<?= base_url('tajwid/input');?>" class="text-white"> <i class="fa fa-eye"></i> Lihat Lainnya.</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $this->load->view('home/modal_view'); ?>
<?php $this->load->view('layout/footer'); ?>
<?php $this->load->view('home/jsv_home'); ?>