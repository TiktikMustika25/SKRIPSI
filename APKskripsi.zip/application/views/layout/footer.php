<div class="bg-app-default p-4 text-center">
	<span class="text-white"> &copy; copyright 2022 | by TiktikMustikawati. </span>
</div>
<?php $this->load->view('pengguna_mv'); ?>
<script src="<?= base_url(); ?>assets/vendor/jquery-3.6.0.min.js"></script>
<script src="<?= base_url(); ?>assets/bs5/js/bootstrap.bundle.min.js"></script>
<script src="<?= base_url(); ?>assets/aos-master/dist/aos.js"></script>
<script>
	var table_pengguna = $('#table-pengguna');
	var form_pengguna_cpwd = $('#form-cpwd-pengguna');
	var form_pengguna_edit = $('#form-edit-pengguna');
	var baseurl = '<?= base_url(); ?>';

	AOS.init({
		once: true,
		delay: 400,
		duration: 1100
	});

	setTimeout(function() {
		$('.myalert-info').fadeOut('slow');
	}, 2500);

	$('#config-theme a').click(function() {
		$('#config-theme2').toggle('slow');
		$('#config-theme-ctx').toggle('slow');
	});

	table_pengguna.on('click', '.btn-cpwd-usr', function() {
		let pid = $(this).attr('pid');
		let nama = $(this).attr('nama');
		form_pengguna_cpwd.collapse('show');
		form_pengguna_cpwd.find('form').attr('action', baseurl + 'pengguna/cpwd_pengguna/' + pid);
		form_pengguna_cpwd.find('input[name="cpwd-nama-usr"]').val(nama);
		form_pengguna_cpwd.find('button[type="button"]').attr('type', 'submit');
	});

	table_pengguna.on('click', '.btn-edit-usr', function() {
		let pid = $(this).attr('pid');
		let nama = $(this).attr('nama');
		let username = $(this).attr('username');
		form_pengguna_edit.collapse('show');
		form_pengguna_edit.find('form').attr('action', baseurl + 'pengguna/edit_pengguna/' + pid);
		form_pengguna_edit.find('input[name="nama-usr-edit"]').val(nama);
		form_pengguna_edit.find('input[name="username-usr-edit"]').val(username);
		form_pengguna_edit.find('button[type="button"]').attr('type', 'submit');
	});
</script>
</body>

</html>