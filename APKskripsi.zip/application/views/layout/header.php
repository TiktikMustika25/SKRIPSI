<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<link rel="shortcut icon" href="<?= base_url('assets/document/favicon.jpeg');?>" type="image/x-icon">

	<title> Pengenalan Huruf Hijaiyah </title>
	<!-- style with bootstrap -->
	<link rel="stylesheet" href="<?= base_url();?>assets/bs5/css/bootstrap.min.css">
	<!-- style with fontawesome -->
	<link rel="stylesheet" href="<?= base_url();?>assets/fontawesome/css/all.min.css">
	<link rel="stylesheet" href="<?= base_url();?>assets/fontawesome/css/brands.min.css">
	<link rel="stylesheet" href="<?= base_url();?>assets/fontawesome/css/fontawesome.min.css">
	<link rel="stylesheet" href="<?= base_url();?>assets/fontawesome/css/regular.min.css">
	<!-- aos animation -->
	<link rel="stylesheet" href="<?= base_url();?>assets/aos-master/dist/aos.css">
	<style>
		html,body{
			background-color:<?= $bg_tema; ?>;
			height:100%;
			margin:0;
		}
		a{
			text-decoration:none;
		}
		.bg-app-default{
			background-color:<?= $nf_tema; ?>;
		}
		.content-app{
			padding-top: 4rem;
			min-height:100%;
			background-color:<?= $cn_tema; ?>;
		}
		.title-app{
			font-family: emoji;
			padding:15px;
			background-color:#fff;
			border-radius:5px;
		}
		#config-theme{
			z-index:99999;
			background-color:rgba(0,0,0,0.17);
			border-top-right-radius:20px;
			border-bottom-right-radius:20px;
			padding:5px;
			padding-right:10px;
			position:fixed;
			top:50px;
			left:0;
		}
		#config-theme a{
			color:#fff !important;
		}
		#config-theme-ctx{
			z-index:99999;
			border-top-right-radius:5px;
			border-bottom-right-radius:5px;
			background-color:rgba(0,0,0,0.17);
			padding-top:10px;
			padding-bottom:10px;
			/* margin-right:25px; */
			width:130px;
			position:fixed;
			top:90px;
			left:1px;
			display:none;
		}
		#config-theme-ctx .config-theme-ctx_{
			height:540px;
			/* height:500px; */
			overflow-y:auto;
		}
		#config-theme-ctx ul li{
			margin-left:-25px;
			margin-right:10px;
			margin-top:10px;
			list-style:none;
		}
		#config-theme-ctx ul li label{
			width:100%;
			padding:5px;
			border-radius:5px;
		}
		#config-theme-ctx .title-theme-ctx{
			border-top-right-radius:5px;
			border-bottom-right-radius:5px;
			background-color:#ffff;
			/* padding:3px; */
			/* right:10px; */
			margin-right:3px;
			/* width:100%; */
			text-align: center;
			font-size:15px;
			font-weight: bold;
		}
		#config-theme-ctx .title-theme-footer{
			/* background-color:#ffff; */
			/* padding:3px; */
			/* right:10px; */
			margin-right:3px;
			/* width:100%; */
			text-align: center;
			font-size:15px;
			font-weight: bold;
		}
		@media screen and (max-width: 769px){
			#config-theme-ctx{
				width:130px !important;
			}
			#config-theme-ctx .config-theme-ctx_{
				height:450px !important;
				/* height:500px; */
				overflow-y:auto;
			}
		}
		.contain-login-show{ display:block; }
		.contain-login-hide{ display:none; }
		#contain-login{
			/* display:none; */
			/* margin:0; */
			height:100%;
			width:100%;
			background-color:rgba(255,255,255,0.95);
			z-index:9999;
			position:fixed;
		}
		#contain-login .card{
			background-color:rgba(195,195,195,0.88);
			top:20%;
			padding:0;
			margin:0 auto;
			border:none;
			/* border-radius:0; */
		}
		#navbarMenu{
			font-family: 'Courier New', Courier, monospace;
			font-weight: bold;
		}
	</style>
</head>
<body>
	<div id="config-theme">
		<a href="javascript:0"><i class="fa fa-cog"></i></a>
	</div>
	<div id="config-theme-ctx">
		<div class="config-theme-ctx_">
			<form action="<?= base_url('home/theme');?>" method="POST">
				<div class="title-theme-ctx"> Background </div>
				<ul>
					<li><label class="bg-white"><input type="radio" name="bg-tema" value="#fff" <?= $bg_tema == '#fff' ? 'checked':''; ?>> Tema 1 </label></li>
					<li><label style="background-color:#585858;color:#fff;"><input type="radio" name="bg-tema" value="#585858" <?= $bg_tema == '#585858' ? 'checked':''; ?>> Tema 2 </label></li>
					<li><label style="background-color:#dbeeef;"><input type="radio" name="bg-tema" value="#dbeeef" <?= $bg_tema == '#dbeeef' ? 'checked':''; ?>> Tema 3 </label></li>
				</ul>
				<div class="title-theme-ctx"> Container </div>
				<ul>
					<li><label style="background-color:#d7d7d7;"><input type="radio" name="cn-tema" value="#d7d7d7" <?= $cn_tema == '#d7d7d7' ? 'checked':''; ?>> Tema 1 </label></li>
					<li><label style="background-color:#dbeeef;"><input type="radio" name="cn-tema" value="#dbeeef" <?= $cn_tema == '#dbeeef' ? 'checked':''; ?>> Tema 2 </label></li>
					<li><label style="background-color:#585858;color:#fff;"><input type="radio" name="cn-tema" value="#585858" <?= $cn_tema == '#585858' ? 'checked':''; ?>> Tema 3 </label></li>
				</ul>
				<div class="title-theme-ctx"> NavFooter </div>
				<ul>
					<li><label class="bg-info text-white"><input type="radio" name="nv-tema" value="#0dcaf0" <?= $nf_tema == '#0dcaf0' ? 'checked':''; ?>> Tema 1 </label></li>
					<li><label style="background-color:#2fbd57;color:#fff;"><input type="radio" name="nv-tema" value="#2fbd57" <?= $nf_tema == '#2fbd57' ? 'checked':''; ?>> Tema 2 </label></li>
					<li><label style="background-color:#dc3545;color:#fff;"><input type="radio" name="nv-tema" value="#dc3545" <?= $nf_tema == '#dc3545' ? 'checked':''; ?>> Tema 2 </label></li>
				</ul>
				<div id="title-theme-footer" class="title-theme-footer m-2">
					<button type="submit" class="btn btn-sm btn-primary w-100 my-1"> <i class="fa fa-check"></i> </button>
					<a href="<?= base_url('home/input');?>" class="btn btn-sm btn-info w-100 my-1"> <i class="fas fa-users"></i> </a>
				</div>
			</form>
		</div>
	</div>
	<div class="p-1 fixed-top bg-app-default text-center">
		<!-- with name icon -->
		<!-- <h4 class="text-center">
			<a class="text-white" href="<?= base_url();?>" title="">LOGO APLIKASI</a>
		</h4> -->
		<!-- with favicon img -->
		<a class="text-white" href="<?= base_url();?>" title="">
			<img src="<?= base_url('assets/document/favicon.jpeg');?>" style="height:55px;width:55px;border-radius:50%;" alt="">
		</a>
	</div>
	<!-- <div class="mt-4"> &nbsp;&nbsp; </div> -->

