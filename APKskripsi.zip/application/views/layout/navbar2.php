<?php
if (!$this->session->userdata('data_penggunaSess')) {
    $nama = null;
    $cols = 'col-xl-12';
} else {
    $cols = 'col-xl-6';
    $nama = $this->session->userdata('data_penggunaSess')['nama'];
} ?>
<div class="title-app mt-2" data-aos="zoom-in-up">
    <h4 class="text-center"> Input Huruf Hijaiyah </h4>
</div>
<!-- Navbar Code -->
<nav class="navbar navbar-expand-lg navbar-light bg-app-default mt-3 py-1">
    <div class="container-fluid">
        <!-- <a class="navbar-brand" href="#">Navbar w/ text</a> -->
        <button class="navbar-toggler mx-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse text-center" id="navbarMenu">
            <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?= $this->uri->segment(1) == 'home' ?? $this->uri->segment(1) == '' ?
                                            'active text-muted' : 'text-white'; ?>" href="<?= base_url('home/input'); ?>"> Home </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $this->uri->segment(1) == 'fathah' ? 'active text-muted' : 'text-white'; ?>" href="<?= base_url('fathah/input'); ?>"> Fathah </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $this->uri->segment(1) == 'kasrah' ? 'active text-muted' : 'text-white'; ?>" href="<?= base_url('kasrah/input'); ?>"> Kasrah </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $this->uri->segment(1) == 'dhammah' ? 'active text-muted' : 'text-white'; ?>" href="<?= base_url('dhammah/input'); ?>"> Dhammah </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $this->uri->segment(1) == 'tanwin_fathah' ? 'active text-muted' : 'text-white'; ?>" href="<?= base_url('tanwin_fathah/input'); ?>"> Tanwin Fathah </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $this->uri->segment(1) == 'tanwin_kasrah' ? 'active text-muted' : 'text-white'; ?>" href="<?= base_url('tanwin_kasrah/input'); ?>"> Tanwin Kasrah</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $this->uri->segment(1) == 'tanwin_dhammah' ? 'active text-muted' : 'text-white'; ?>" href="<?= base_url('tanwin_dhammah/input'); ?>"> Tanwin Dhammah </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $this->uri->segment(1) == 'tajwid' ? 'active text-muted' : 'text-white'; ?>" href="<?= base_url('tajwid/input'); ?>"> Tajwid </a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<div class="row">
    <div class="col-xl-12" data-aos="zoom-in-right">
        <a href="<?= base_url('home');?>" class="btn btn-outline-primary btn-sm w-100 mb-1 mt-2"> <i class="fa fa-home"></i> Home (Utama) </a>
    </div>
    <div class="<?= $cols; ?>" data-aos="zoom-in-right">
        <button class="btn btn-outline-info w-100 mb-1 mt-2" data-bs-toggle="modal" data-bs-target="#m-data-pengguna"> <i class="fa fa-users"></i> Data Pengguna </button>
    </div>
    <?php if ($nama != null) { ?>
        <div class="<?= $cols; ?>" data-aos="zoom-in-left">
            <a onClick="return confirm('keluar dari akun ( <?= $nama; ?> ) ?');" href="<?= base_url('pengguna/psOut/' . $this->uri->segment(1)); ?>" class="btn btn-outline-danger w-100 mb-1 mt-2"> <i class="fa fa-sign-out"></i> <?= $nama; ?> </a>
        </div>
    <?php } ?>
</div>