<script>
	
	'use strict';

	$(document).ready(function(t){
		
		var contentHurupHijaiyah = t('#ctx-huruphijaiyah');
		var hurup_hijaiyah_ctx = t('#area-hurup-hijaiyah');
		var mhh_edit = t('#m-edit-hurup');
		
		contentHurupHijaiyah.on('click','.hurup-hijaiyah',function(){
			let hhid = t(this).attr('hhid');
			let hsound = t('audio#hsound-' + hhid);
			t(this)
			.addClass('hurup-hijaiyah-collapses')
			.removeClass('hurup-hijaiyah');
			hsound[0].play();
		});

		contentHurupHijaiyah.on('click','.hurup-hijaiyah-collapses',function(){
			let hhid = t(this).attr('hhid');
			let hsound = t('audio#hsound-' + hhid);
			t(this)
			.addClass('hurup-hijaiyah')
			.removeClass('hurup-hijaiyah-collapses');
			hsound[0].pause();
		});


		hurup_hijaiyah_ctx.on('click','.btn-edit-hh',function(){
			let hhid = t(this).attr('hhid');
			t.getJSON(baseurl+'fathah/ambilHurupByIdJSON/'+hhid, function(data, statusJSON){
				mhh_edit.modal('show');
				console.log('ambil data hurup status:'+statusJSON);
				mhh_edit.find('form').attr('action',baseurl+'fathah/edit/'+hhid);
				mhh_edit.find('input[name="hurup1-edit"]').val(data.hurup_1);
				mhh_edit.find('input[name="hurup2-edit"]').val(data.hurup_2);
				mhh_edit.find('#info-file-hurup-edit').html(`File Sound: ${data.sound}`);
				mhh_edit.find('input[name="sound-hurup-edit_2"]').val(data.sound);
				mhh_edit.find('input[name="cbg-hurup-edit"]').val(data.cbg);
				mhh_edit.find('input[name="ctxt-hurup-edit"]').val(data.ctxt);
				mhh_edit.find('textarea[name="desc-hurup-edit"]').val(data.deskripsi);
			});
		});

		hurup_hijaiyah_ctx.on('click','.btn-play-sound',function(){
			var sources = t(this).attr('hsound');
			var hhid = t(this).attr('hhid');
			t(this).removeClass('btn-play-sound')
			.addClass('btn-stop-sound')
			.find('i.fa-music')
			.removeClass('fa-music')
			.addClass('fa-pause')
			.attr('title','stop-sound');
			t('audio#hsound-' + hhid)[0].play();
		});

		hurup_hijaiyah_ctx.on('click','.btn-stop-sound',function(){
			var sources = t(this).attr('hsound');
			var hhid = t(this).attr('hhid');
			t(this).removeClass('btn-stop-sound')
			.addClass('btn-play-sound')
			.find('i.fa-pause')
			.removeClass('fa-pause')
			.addClass('fa-music')
			.attr('title','play-sound');
			t('audio#hsound-' + hhid)[0].pause();
		});
	});
</script>