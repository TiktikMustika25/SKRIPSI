<?php $this->load->view('layout/header'); ?>
<div class="container content-app">
	<?php $this->load->view('layout/navbar'); ?>
	<div class="row" id="ctx-huruphijaiyah">
		<?php $n = 0;
		foreach ($tanwin_fathah as $row) { ?>
			<div class="col-xl-3 my-3" data-aos="zoom-in">
				<audio id="hsound-<?= $row['id']; ?>" autoloop loop style="display:none;">
					<source src="<?= base_url('assets/upload/' . $row['sound']); ?>" type="audio/mpeg">
				</audio>
				<div class="card shadow" style="background-color:<?= $row['cbg']; ?>;color:<?= $row['ctxt']; ?>;">
					<div class="card-header text-center bg-transparent p-3">
						<a class="text-white hurup-hijaiyah" hhid="<?= $row['id']; ?>" style="text-decoration:none;color:#fff;" data-bs-toggle="collapse" href="#hurup-<?= $row['id']; ?>">
							<h1><?= $row['hurup_1']; ?></h1>
							<small><i><?= $row['hurup_2']; ?></i></small>
						</a>
					</div>
					<div class="card-body collapse hurup-<?= $row['id']; ?>" id="hurup-<?= $row['id']; ?>">
						<div><?= $row['deskripsi']; ?></div>
					</div>
				</div>
			</div>
		<?php $n++;
		} ?>
	</div>
</div>
<?php $this->load->view('layout/footer'); ?>
<?php $this->load->view('tanwin_fathah/jsv_input'); ?>