<?php $this->load->view('layout/header'); ?>
<?php $this->load->view('login_view');?>
<div class="container content-app">
	<?php $this->load->view('layout/navbar2'); ?>
	<button class="btn btn-outline-success w-100 mt-1 mb-2" data-aos="zoom-in" data-bs-toggle="modal" data-bs-target="#m-tambah-hurup"> <i class="fa fa-plus-circle"></i> Tambah Hurup </button>
	<div><?= $this->session->flashdata('pesan_data'); ?></div>
	<div class="row" id="area-hurup-hijaiyah">
		<?php $n=0; foreach ($tanwin_fathah as $row){ ?>
			<div class="col-xl-3 my-3" data-aos="zoom-in-left">
				<audio id="hsound-<?= $row['id'];?>" autoloop loop style="display:none;">
					<source src="<?= base_url('assets/upload/'.$row['sound']);?>" type="audio/mpeg">
				</audio>
				<div class="card shadow" style="background-color:<?= $row['cbg'];?>;color:<?= $row['ctxt'];?>;">
					<div class="card-header text-center">
						<h1><?= $row['hurup_1'];?></h1>
						<small><i><?= $row['hurup_2'];?></i></small>
						<div class="mt-2 p-2" style="background-color:rgba(0,0,0,0.35);border-radius:5px;">
							<a data-bs-toggle="collapse" href="#hurup<?= $n;?>" class="btn btn-info btn-sm"> <i class="fa fa-info-circle"></i> </a>
							<?php if ($row['sound'] != '' || $row['sound'] != null){ ?>
								<a class="btn btn-warning btn-sm btn-play-sound" hsound="<?= $row['sound'];?>" hhid="<?= $row['id'];?>"> <i class="fa fa-music"></i> </a>
							<?php } ?>
							<a href="javascript:0" hhid="<?= $row['id'];?>" class="btn btn-primary btn-sm btn-edit-hh" title="play-sound"> <i class="fa fa-edit"></i> </a>
							<a onClick="return confirm('hapus hurup <?= $row['hurup_2'];?> ?');" href="<?= base_url('tanwin_fathah/hapus_data/'.$row['id']);?>" class="btn btn-danger btn-sm"> <i class="fa fa-trash"></i> </a>
						</div>
					</div>
					<div class="card-body collapse" id="hurup<?= $n;?>">
						<div>
							<p><?= $row['deskripsi'];?></p>
						</div>
					</div>
				</div>
			</div>
		<?php $n++; } ?>
	</div>
</div>
<?php $this->load->view('tanwin_fathah/modal_view');?>
<?php $this->load->view('layout/footer'); ?>
<?php $this->load->view('tanwin_fathah/jsv_input'); ?>