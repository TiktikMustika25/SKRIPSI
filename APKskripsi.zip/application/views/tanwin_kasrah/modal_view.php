<!--Modal tanwin_kasrah Tambah-->
<div class="modal fade" id="m-tambah-hurup">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-body">
				<button type="button" class="btn btn-sm close float-end" data-bs-dismiss="modal"> <i class="fa fa-times"></i> </button>
				<h4 class="text-center p-2"> Form tambah tanwin kasrah</h4>
				<form action="<?= base_url('tanwin_kasrah/tambah');?>" enctype="multipart/form-data" method="post">
					<div class="row">
						<div class="col-6">
							<div class="my-3">
								<label class="w-100">
									Hurup Latin (required)
									<input class="form-control" type="text" name="hurup1-ins" placeholder="contoh: ب   " required>
								</label>
							</div>
						</div>
						<div class="col-6">
							<div class="my-3">
								<label class="w-100">
									Hurup Biasa (required)
									<input class="form-control" type="text" name="hurup2-ins" placeholder="contoh: (Ba)" required>
								</label>
							</div>
						</div>
					</div>
					<div class="my-3">
						<label class="w-100">
							Hurup Bacaan (default null)
							<input class="form-control" type="file" name="sound-hurup-ins">
						</label>
					</div>
					<div class="my-3">
						<div class="row">
							<div class="col-6">
								<label class="w-100">
									warna background hurup
									<input class="form-control" name="cbg-hurup-ins" type="color" required>
								</label>
							</div>
							<div class="col-6">
								<label class="w-100">
									warna teks hurup
									<input class="form-control" name="ctxt-hurup-ins" type="color" required>
								</label>
							</div>
						</div>
					</div>
					<div class="my-3">
						<label class="w-100">
							Penjelasan Hurup (default null)
							<textarea class="form-control" rows="3" name="desc-hurup-ins" placeholder="makhraj hurup, tajwid, penjelasan.."></textarea>
						</label>
					</div>
					<div class="my-3">
						<button type="submit" class="btn btn-success"> tambah </button>
						<button type="button" class="btn btn-danger" data-bs-dismiss="modal"> tutup </button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<!-- Modal tanwin_kasrah Edit-->
<div class="modal fade" id="m-edit-hurup">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-body">
				<button type="button" class="btn btn-sm close float-end" data-bs-dismiss="modal"> <i class="fa fa-times"></i> </button>
				<h4 class="text-center p-2"> Form edit tanwin kasrah</h4>
				<form action="<?= base_url('tanwin_kasrah/edit');?>" enctype="multipart/form-data" method="post">
					<div class="row">
						<div class="col-6">
							<div class="my-3">
								<label class="w-100">
									Hurup Latin (required)
									<input class="form-control" type="text" name="hurup1-edit" placeholder="contoh: ب   " required>
								</label>
							</div>
						</div>
						<div class="col-6">
							<div class="my-3">
								<label class="w-100">
									Hurup Biasa (required)
									<input class="form-control" type="text" name="hurup2-edit" placeholder="contoh: (Ba)" required>
								</label>
							</div>
						</div>
					</div>
					<div class="my-3">
						<label class="w-100">
							Hurup Bacaan (default null)<br>
							<span id="info-file-hurup-edit"> File Sound: <i>null</i></span>
							<input class="form-control" type="file" name="sound-hurup-edit">
						</label>
						<input class="form-control" type="hidden" name="sound-hurup-edit_2">
					</div>
					<div class="my-3">
						<div class="row">
							<div class="col-6">
								<label class="w-100">
									warna background hurup
									<input class="form-control" name="cbg-hurup-edit" type="color" required>
								</label>
							</div>
							<div class="col-6">
								<label class="w-100">
									warna teks hurup
									<input class="form-control" name="ctxt-hurup-edit" type="color" required>
								</label>
							</div>
						</div>
					</div>
					<div class="my-3">
						<label class="w-100">
							Penjelasan Hurup (default null)
							<textarea class="form-control" rows="3" name="desc-hurup-edit" placeholder="makhraj hurup, tajwid, penjelasan.."></textarea>
						</label>
					</div>
					<div class="my-3">
						<button type="submit" class="btn btn-primary"> edit </button>
						<button type="button" class="btn btn-danger" data-bs-dismiss="modal"> tutup </button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<!-- Modal tanwin kasrah End -->