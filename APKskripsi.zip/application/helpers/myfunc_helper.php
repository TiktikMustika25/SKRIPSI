<?php 

function ci()
{
    return $CI =& get_instance();
}
function SessTheme()
{
    $config_tema = ci()->session->userdata('config_tema');
    if (isset($config_tema['bg_tema']) && isset($config_tema['cn_tema']) && isset($config_tema['nf_tema'])) {
        $x = array(
            'bg_tema' => $config_tema['bg_tema'], 
            'cn_tema' => $config_tema['cn_tema'], 
            'nf_tema' => $config_tema['nf_tema'], 
        );
    } else {
        $x = array(
            'bg_tema' => '#fff', 
            'cn_tema' => '#d7d7d7', 
            'nf_tema' => '#0dcaf0', 
        );
    }
    return $x;
}

?>