<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model extends CI_Model {

	function tampilsemuadatahuruphijaiyah()
	{
		$query = $this->db->select('*')
		->from('hurup_hijaiyah')
		->order_by('tgl_input','asc')
		->get();
		return $query->result_array();
	}
	function tampilsemuadatafathah()
	{
		$query = $this->db->select('*')
		->from('fathah')
		->order_by('tgl_input','asc')
		->get();
		return $query->result_array();
	}
	function tampilsemuadatakasrah()
	{
		$query = $this->db->select('*')
		->from('kasrah')
		->order_by('tgl_input','asc')
		->get();
		return $query->result_array();
	}
	function tampilsemuadatadhammah()
	{
		$query = $this->db->select('*')
		->from('dhammah')
		->order_by('tgl_input','asc')
		->get();
		return $query->result_array();
	}
	function tampilsemuadatatanwinfathah()
	{
		$query = $this->db->select('*')
		->from('tanwin_fathah')
		->order_by('tgl_input','asc')
		->get();
		return $query->result_array();
	}
	function tampilsemuadatatanwinkasrah()
	{
		$query = $this->db->select('*')
		->from('tanwin_kasrah')
		->order_by('tgl_input','asc')
		->get();
		return $query->result_array();
	}
	function tampilsemuadatatanwindhammah()
	{
		$query = $this->db->select('*')
		->from('tanwin_dhammah')
		->order_by('tgl_input','asc')
		->get();
		return $query->result_array();
	}
	function tampilsemuadatatajwid()
	{
		$query = $this->db->select('*')
		->from('tajwid')
		->order_by('tgl_input','asc')
		->get();
		return $query->result_array();
	}
	function tampilsemuadatapengguna()
	{
		$query = $this->db->select('*')
		->from('pengguna')
		->order_by('p_id','asc')
		->get();
		return $query->result_array();
	}
	function ambilPenggunaBy($where)
	{
		$query = $this->db->get_where('pengguna', $where);
		return $query->row_array();	
	}
	function ambilHurupById($hhid)
	{
		$query = $this->db->get_where('hurup_hijaiyah',['id'=>$hhid]);
		return $query->row_array();
	}
	function ambilHurupByWhere($table, $where)
	{
		$query = $this->db->get_where($table, $where);
		return $query->row_array();
	}

}

/* End of file Model.php */
/* Location: ./application/models/Model.php */