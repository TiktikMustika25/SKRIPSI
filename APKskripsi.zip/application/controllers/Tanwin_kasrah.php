<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Tanwin_kasrah extends CI_Controller {

    public function index()
	{
        $x = SessTheme();
        $x['tanwin_kasrah'] = $this->model->tampilsemuadatatanwinkasrah();
		$this->load->view('tanwin_kasrah/home_view', $x);
	}
    public function input()
    {
        $x = SessTheme();
        $x['tanwin_kasrah'] = $this->model->tampilsemuadatatanwinkasrah();
        $x['pengguna'] = $this->model->tampilsemuadatapengguna();
        $this->load->view('tanwin_kasrah/input_view', $x);
    }
    function ambilHurupByIdJSON($id)
	{
		$hh = $this->model->ambilHurupByWhere('tanwin_kasrah', ['id'=>$id]);
		echo json_encode($hh);
	}
	function tambah()
	{
		$config['upload_path'] = 'assets/upload/';
		$config['allowed_types'] = 'mp3|3gp|*';
		$config['max_size']  = '24000'; //24mb
		$config['encrypt_name']  = true; //enkripsi nama file
		
		$this->load->library('upload', $config);
		
		if ($this->upload->do_upload('sound-hurup-ins')){
			$sound = $this->upload->data('file_name');
		}
		else{
			$sound = '';
		}

		$data = array(
			'hurup_1' => $this->input->post('hurup1-ins'),
			'hurup_2' => $this->input->post('hurup2-ins'),
			'sound' => $sound,
			'cbg' => $this->input->post('cbg-hurup-ins'),
			'ctxt' => $this->input->post('ctxt-hurup-ins'),
			'tgl_input' => date('y/m/d H:i:s'),
			'deskripsi' => $this->input->post('desc-hurup-ins')
		);

		$db = $this->db->insert('tanwin_kasrah', $data);

		if ($db==1||$db==true){
			$this->session->set_flashdata('pesan_data','<div class="alert alert-success bg-success text-white w-100 myalert-info"> <strong>berhasil</strong> tambah data hurup tanwin kasrah.. </div>');
		} else {
			$this->session->set_flashdata('pesan_data','<div class="alert alert-danger bg-danger text-white w-100 myalert-info"> <strong>gagal</strong> tambah data hurup tanwin kasrah!! </div>');
		}
		redirect('tanwin_kasrah/input');
	}
	function hapus_data($id)
	{
		$hh = $this->model->ambilHurupByWhere('tanwin_kasrah', ['id'=>$id]);

		if (isset($hh['sound'])){
			unlink('assets/upload/'.$hh['sound']);
		}

		$db = $this->db->delete('tanwin_kasrah', ['id' => $id]);

		if ($db==1||$db==true){
			$this->session->set_flashdata('pesan_data','<div class="alert alert-success bg-success text-white w-100 myalert-info"> <strong>berhasil</strong> hapus data hurup tanwin kasrah.. </div>');
		} else {
			$this->session->set_flashdata('pesan_data','<div class="alert alert-danger bg-danger text-white w-100 myalert-info"> <strong>gagal</strong> hapus data hurup tanwin kasrah!! </div>');
		}
		redirect('tanwin_kasrah/input');
	}
	function edit($id)
	{
		$config['upload_path'] = 'assets/upload/';
		$config['allowed_types'] = 'mp3|3gp|*';
		$config['max_size']  = '24000'; //24mb
		$config['encrypt_name']  = true; //enkripsi nama file
		
		$this->load->library('upload', $config);
		$soundLama = $this->input->post('sound-hurup-edit_2');

		if ($this->upload->do_upload('sound-hurup-edit')){

			if (isset($soundLama)){
				unlink('assets/upload/'.$soundLama);
			}

			$sound = $this->upload->data('file_name');
		}
		else{
			$sound = $soundLama;
		}

		$data = array(
			'hurup_1' => $this->input->post('hurup1-edit'),
			'hurup_2' => $this->input->post('hurup2-edit'),
			'sound' => $sound,
			'cbg' => $this->input->post('cbg-hurup-edit'),
			'ctxt' => $this->input->post('ctxt-hurup-edit'),
			'deskripsi' => $this->input->post('desc-hurup-edit')
		);

		$db = $this->db->update('tanwin_kasrah', $data, ['id'=>$id]);

		if ($db==1||$db==true){
			$this->session->set_flashdata('pesan_data','<div class="alert alert-success bg-success text-white w-100 myalert-info"> <strong>berhasil</strong> edit data hurup tanwin kasrah.. </div>');
		} else {
			$this->session->set_flashdata('pesan_data','<div class="alert alert-danger bg-danger text-white w-100 myalert-info"> <strong>gagal</strong> edit data hurup tanwin kasrah!! </div>');
		}

		redirect('tanwin_kasrah/input');
	}

}

/* End of file Tanwin_kasrah.php */
