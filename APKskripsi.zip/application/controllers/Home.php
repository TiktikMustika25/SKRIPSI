<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index()
	{
		$x = SessTheme();
		$x['hhijaiyah'] = $this->model->tampilsemuadatahuruphijaiyah();
		$x['total_fathah'] = $this->db->get('fathah')->num_rows();
		$x['total_kasrah'] = $this->db->get('kasrah')->num_rows();
		$x['total_dhammah'] = $this->db->get('dhammah')->num_rows();
		$x['total_tfathah'] = $this->db->get('tanwin_fathah')->num_rows();
		$x['total_tkasrah'] = $this->db->get('tanwin_kasrah')->num_rows();
		$x['total_tdhammah'] = $this->db->get('tanwin_dhammah')->num_rows();
		$x['total_tajwid'] = $this->db->get('tajwid')->num_rows();
		$this->load->view('home/home_view', $x);
	}
	function theme()
	{
		$bg_tema = $this->input->post('bg-tema');
		$container_tema = $this->input->post('cn-tema');
		$navbarFooter_tema = $this->input->post('nv-tema');
		
		$this->session->set_userdata('config_tema',[
			'bg_tema' => $bg_tema,
			'cn_tema' => $container_tema,
			'nf_tema' => $navbarFooter_tema
		]);
		redirect('');
	}
	public function input()
	{
		$x = SessTheme();
		$x['hhijaiyah'] = $this->model->tampilsemuadatahuruphijaiyah();
		$x['pengguna'] = $this->model->tampilsemuadatapengguna();
		$x['total_pengguna'] = $this->db->get('pengguna')->num_rows();
		$x['total_fathah'] = $this->db->get('fathah')->num_rows();
		$x['total_kasrah'] = $this->db->get('kasrah')->num_rows();
		$x['total_dhammah'] = $this->db->get('dhammah')->num_rows();
		$x['total_tfathah'] = $this->db->get('tanwin_fathah')->num_rows();
		$x['total_tkasrah'] = $this->db->get('tanwin_kasrah')->num_rows();
		$x['total_tdhammah'] = $this->db->get('tanwin_dhammah')->num_rows();
		$x['total_tajwid'] = $this->db->get('tajwid')->num_rows();
		$this->load->view('home/input_view', $x);
	}
	function ambilHurupByIdJSON($hhid)
	{
		$hh = $this->model->ambilHurupById($hhid);
		echo json_encode($hh);
	}
	function tambah()
	{
		$config['upload_path'] = 'assets/upload/';
		$config['allowed_types'] = 'mp3|3gp|*';
		$config['max_size']  = '24000'; //24mb
		$config['encrypt_name']  = true; //enkripsi nama file
		
		$this->load->library('upload', $config);
		
		if ($this->upload->do_upload('sound-hurup-ins')){
			$sound = $this->upload->data('file_name');
		}
		else{
			$sound = '';
		}

		$data = array(
			'hurup_1' => $this->input->post('hurup1-ins'),
			'hurup_2' => $this->input->post('hurup2-ins'),
			'h_sound' => $sound,
			'h_cbg' => $this->input->post('cbg-hurup-ins'),
			'h_ctxt' => $this->input->post('ctxt-hurup-ins'),
			'tgl_input' => date('y/m/d H:i:s'),
			'deskripsi' => $this->input->post('desc-hurup-ins')
		);

		$db = $this->db->insert('hurup_hijaiyah', $data);

		if ($db==1||$db==true){
			$this->session->set_flashdata('pesan_data','<div class="alert alert-success bg-success text-white w-100 myalert-info"> <strong>berhasil</strong> tambah data hurup hijaiyah.. </div>');
		} else {
			$this->session->set_flashdata('pesan_data','<div class="alert alert-danger bg-danger text-white w-100 myalert-info"> <strong>gagal</strong> tambah data hurup hijaiyah!! </div>');
		}
		redirect('home/input');
	}
	function hapus_data($hhid)
	{
		$hh = $this->model->ambilHurupById($hhid);

		if (isset($hh['sound'])){
			unlink('assets/upload/'.$hh['sound']);
		}

		$db = $this->db->delete('hurup_hijaiyah', ['id' => $hhid]);

		if ($db==1||$db==true){
			$this->session->set_flashdata('pesan_data','<div class="alert alert-success bg-success text-white w-100 myalert-info"> <strong>berhasil</strong> hapus data hurup hijaiyah.. </div>');
		} else {
			$this->session->set_flashdata('pesan_data','<div class="alert alert-danger bg-danger text-white w-100 myalert-info"> <strong>gagal</strong> hapus data hurup hijaiyah!! </div>');
		}
		redirect('home/input');
	}
	function edit($hhid)
	{
		$config['upload_path'] = 'assets/upload/';
		$config['allowed_types'] = 'mp3|3gp|*';
		$config['max_size']  = '24000'; //24mb
		$config['encrypt_name']  = true; //enkripsi nama file
		
		$this->load->library('upload', $config);
		$soundLama = $this->input->post('sound-hurup-edit_2');

		if ($this->upload->do_upload('sound-hurup-edit')){

			if (isset($soundLama)){
				unlink('assets/upload/'.$soundLama);
			}

			$sound = $this->upload->data('file_name');
		}
		else{
			$sound = $soundLama;
		}

		$data = array(
			'hurup_1' => $this->input->post('hurup1-edit'),
			'hurup_2' => $this->input->post('hurup2-edit'),
			'h_sound' => $sound,
			'h_cbg' => $this->input->post('cbg-hurup-edit'),
			'h_ctxt' => $this->input->post('ctxt-hurup-edit'),
			'deskripsi' => $this->input->post('desc-hurup-edit')
		);

		$db = $this->db->update('hurup_hijaiyah', $data, ['id'=>$hhid]);

		if ($db==1||$db==true){
			$this->session->set_flashdata('pesan_data','<div class="alert alert-success bg-success text-white w-100 myalert-info"> <strong>berhasil</strong> edit data hurup hijaiyah.. </div>');
		} else {
			$this->session->set_flashdata('pesan_data','<div class="alert alert-danger bg-danger text-white w-100 myalert-info"> <strong>gagal</strong> edit data hurup hijaiyah!! </div>');
		}
		redirect('home/input');
	}

}

/* End of file Home.php */
/* Location: ./application/controllers/Home.php */