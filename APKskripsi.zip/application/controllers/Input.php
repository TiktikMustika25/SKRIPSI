<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Input extends CI_Controller {

	public function index()
	{
		$config_tema = $this->session->userdata('config_tema');
		if (isset($config_tema['bg_tema']) && isset($config_tema['cn_tema']) && isset($config_tema['nf_tema'])){
			$x['bg_tema'] = $config_tema['bg_tema'];
			$x['cn_tema'] = $config_tema['cn_tema'];
			$x['nf_tema'] = $config_tema['nf_tema'];
		} else {
			$x['bg_tema'] = '#fff';
			$x['cn_tema'] = '#d7d7d7';
			$x['nf_tema'] = '#0dcaf0';
		}
		$x['hhijaiyah'] = $this->model->tampilsemuadatahuruphijaiyah();
		$x['pengguna'] = $this->model->tampilsemuadatapengguna();
		$this->load->view('input_view', $x);
	}
	function ambilHurupByIdJSON($hhid)
	{
		$hh = $this->model->ambilHurupById($hhid);
		echo json_encode($hh);
	}
	function tambah()
	{
		$config['upload_path'] = 'assets/upload/';
		$config['allowed_types'] = 'mp3|3gp|*';
		$config['max_size']  = '24000'; //24mb
		$config['encrypt_name']  = true; //enkripsi nama file
		
		$this->load->library('upload', $config);
		
		if ($this->upload->do_upload('sound-hurup-ins')){
			$sound = $this->upload->data('file_name');
		}
		else{
			$sound = '';
		}

		$data = array(
			'hh_id' => rand(),
			'hurup_1' => $this->input->post('hurup1-ins'),
			'hurup_2' => $this->input->post('hurup2-ins'),
			'h_sound' => $sound,
			'h_cbg' => $this->input->post('cbg-hurup-ins'),
			'h_ctxt' => $this->input->post('ctxt-hurup-ins'),
			'tgl_input' => date('y/m/d H:i:s'),
			'deskripsi' => $this->input->post('desc-hurup-ins')
		);

		$db = $this->db->insert('hurup_hijaiyah', $data);

		if ($db==1||$db==true){
			$this->session->set_flashdata('pesan_data','<div class="alert alert-success bg-success text-white w-100 myalert-info"> <strong>berhasil</strong> tambah data hurup hijaiyah.. </div>');
		} else {
			$this->session->set_flashdata('pesan_data','<div class="alert alert-danger bg-danger text-white w-100 myalert-info"> <strong>gagal</strong> tambah data hurup hijaiyah!! </div>');
		}
		redirect('input');
	}
	function hapus_data($hhid)
	{
		$hh = $this->model->ambilHurupById($hhid);

		if (isset($hh['h_sound'])){
			unlink('assets/upload/'.$hh['h_sound']);
		}

		$db = $this->db->delete('hurup_hijaiyah',['hh_id'=>$hhid]);

		if ($db==1||$db==true){
			$this->session->set_flashdata('pesan_data','<div class="alert alert-success bg-success text-white w-100 myalert-info"> <strong>berhasil</strong> hapus data hurup hijaiyah.. </div>');
		} else {
			$this->session->set_flashdata('pesan_data','<div class="alert alert-danger bg-danger text-white w-100 myalert-info"> <strong>gagal</strong> hapus data hurup hijaiyah!! </div>');
		}
		redirect('input');
	}
	function edit($hhid)
	{
		$config['upload_path'] = 'assets/upload/';
		$config['allowed_types'] = 'mp3|3gp|*';
		$config['max_size']  = '24000'; //24mb
		$config['encrypt_name']  = true; //enkripsi nama file
		
		$this->load->library('upload', $config);
		$soundLama = $this->input->post('sound-hurup-edit_2');

		if ($this->upload->do_upload('sound-hurup-edit')){

			if (isset($soundLama)){
				unlink('assets/upload/'.$soundLama);
			}

			$sound = $this->upload->data('file_name');
		}
		else{
			$sound = $soundLama;
		}

		$data = array(
			'hurup_1' => $this->input->post('hurup1-edit'),
			'hurup_2' => $this->input->post('hurup2-edit'),
			'h_sound' => $sound,
			'h_cbg' => $this->input->post('cbg-hurup-edit'),
			'h_ctxt' => $this->input->post('ctxt-hurup-edit'),
			'deskripsi' => $this->input->post('desc-hurup-edit')
		);

		$db = $this->db->update('hurup_hijaiyah', $data, ['hh_id'=>$hhid]);

		if ($db==1||$db==true){
			$this->session->set_flashdata('pesan_data','<div class="alert alert-success bg-success text-white w-100 myalert-info"> <strong>berhasil</strong> edit data hurup hijaiyah.. </div>');
		} else {
			$this->session->set_flashdata('pesan_data','<div class="alert alert-danger bg-danger text-white w-100 myalert-info"> <strong>gagal</strong> edit data hurup hijaiyah!! </div>');
		}
		redirect('input');
	}

}

/* End of file Input.php */
/* Location: ./application/controllers/Input.php */