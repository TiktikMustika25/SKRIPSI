<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Pengguna extends CI_Controller {

    function tambah_pengguna($uri=null)
	{
		$data = array(
			'nama' => $this->input->post('nama-usr-ins'),
			'username' => $this->input->post('username-usr-ins'),
			'password' => password_hash($this->input->post('password-usr-ins'), PASSWORD_DEFAULT)
		);

		$db = $this->db->insert('pengguna', $data);

		if ($db==1||$db==true){
			$this->session->set_flashdata('pesan_data','<div class="alert alert-success bg-success text-white w-100 myalert-info"> <strong>berhasil</strong> tambah data pengguna.. </div>');
		} else {
			$this->session->set_flashdata('pesan_data','<div class="alert alert-danger bg-danger text-white w-100 myalert-info"> <strong>gagal</strong> tambah data pengguna!! </div>');
		}
		redirect($uri.'/input');
	}
	function hapus_pengguna($pid, $uri)
	{
		$db = $this->db->delete('pengguna', ['p_id' => $pid]);

		if ($db==1||$db==true){
			$this->session->set_flashdata('pesan_data','<div class="alert alert-success bg-success text-white w-100 myalert-info"> <strong>berhasil</strong> hapus data pengguna.. </div>');
		} else {
			$this->session->set_flashdata('pesan_data','<div class="alert alert-danger bg-danger text-white w-100 myalert-info"> <strong>gagal</strong> hapus data pengguna!! </div>');
		}
		redirect($uri.'/input');
	}
	function cpwd_pengguna($pid, $uri)
	{
		$data = array('password' => password_hash($this->input->post('cpwd-usr'), PASSWORD_DEFAULT));

		$db = $this->db->update('pengguna', $data, ['p_id' => $pid]);

		if ($db==1||$db==true){
			$this->session->set_flashdata('pesan_data','<div class="alert alert-success bg-success text-white w-100 myalert-info"> <strong>berhasil</strong> ubah password data pengguna.. </div>');
		} else {
			$this->session->set_flashdata('pesan_data','<div class="alert alert-danger bg-danger text-white w-100 myalert-info"> <strong>gagal</strong> ubah password data pengguna!! </div>');
		}
		redirect($uri.'/input');
	}
	function edit_pengguna($pid, $uri=null)
	{
		$data = array(
			'nama' => $this->input->post('nama-usr-edit'),
			'username' => $this->input->post('username-usr-edit')
		);

		$db = $this->db->update('pengguna', $data, ['p_id' => $pid]);

		if ($db==1||$db==true){
			$this->session->set_flashdata('pesan_data','<div class="alert alert-success bg-success text-white w-100 myalert-info"> <strong>berhasil</strong> edit data pengguna.. </div>');
		} else {
			$this->session->set_flashdata('pesan_data','<div class="alert alert-danger bg-danger text-white w-100 myalert-info"> <strong>gagal</strong> edit data pengguna!! </div>');
		}
		redirect($uri.'/input');
	}
	function login_process($uri=null)
	{
		$username = $this->input->post('username');
		$password = $this->input->post('password');

		$pengguna = $this->model->ambilPenggunaBy(['username' => $username]);

		if ($pengguna == true){
			if (password_verify($password, $pengguna['password'])){
				$this->session->set_userdata('data_penggunaSess',[
					'p_id' => $pengguna['p_id'],
					'nama' => $pengguna['nama'],
					'username' => $pengguna['username'],
					'password' => $pengguna['password']
				]);
			} else {
				$this->session->set_flashdata('pesan_data','<div class="alert alert-warning w-100 myalert-info"> <strong>gagal</strong> password salah!! </div>');
			}
		} else {
			$this->session->set_flashdata('pesan_data','<div class="alert alert-danger w-100 myalert-info"> <strong>gagal</strong> data pengguna tidak ditemukan, pastikan username benar!! </div>');
		}
		redirect($uri.'/input');
	}
	public function psOut($uri=null)
	{
		$this->session->unset_userdata('data_penggunaSess');
		redirect($uri.'/input');
	}

}

/* End of file Pengguna.php */
